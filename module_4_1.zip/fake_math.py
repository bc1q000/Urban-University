def fake_divide(first, second):
    if second == 0:
        return 'Error'
    else:
        return first / second

